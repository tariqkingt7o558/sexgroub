<?php
$telegram_id = "1798061038";
$id_bot = "6652564488:AAGWP9PCdSg9WKc7TT8v9Z83S3TkP9kUnfc";
?>
